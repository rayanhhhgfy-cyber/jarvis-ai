@echo off
title Jarvis Desktop Client
cd /d "%~dp0"
echo Installing dependencies (first run may take a minute)...
python -m pip install -q -r requirements.txt
set PYTHONPATH=%CD%
echo Starting Jarvis daemon ??? keep this window open.
python -m local_client.daemon
pause
