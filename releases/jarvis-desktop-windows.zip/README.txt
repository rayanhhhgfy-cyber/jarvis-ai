﻿Jarvis Desktop Client
=====================
1. Install Python 3.10+ from https://www.python.org/downloads/
2. Extract this ZIP anywhere (e.g. Desktop\JarvisDesktop)
3. Double-click Start-Jarvis-Desktop.bat
4. Ensure the backend is running: http://localhost:8000
5. Pair your device via the web dashboard if needed (pair_device.py on full repo)
